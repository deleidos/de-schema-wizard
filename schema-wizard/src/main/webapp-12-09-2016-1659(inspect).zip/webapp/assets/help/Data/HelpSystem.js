var xmlHelpSystemData = "";
xmlHelpSystemData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlHelpSystemData += '<WebHelpSystem DefaultUrl=\"Content/Welcome.htm\" Toc=\"Data/Toc.js\" Index=\"Data/Index.js\" Concepts=\"Data/Concepts.xml\" BrowseSequence=\"Data/BrowseSequence.js\" Glossary=\"Data/Glossary.js\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" SkinName=\"HTML5 - TriPane\" Skins=\"HTML5 - TriPane\" BuildTime=\"5/13/2016 3:48:54 PM\" BuildVersion=\"10.2.2.0\" TargetType=\"WebHelp2\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\">';
xmlHelpSystemData += '    <CatapultSkin Version=\"2\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"True\" RemoveImagesOnSave=\"true\" EnableResponsiveOutput=\"true\" Name=\"HTML5 - TriPane\">';
xmlHelpSystemData += '        <Toolbar EnableCustomLayout=\"true\" Buttons=\"Filler|PreviousTopic|CurrentTopicIndex|NextTopic|SelectLanguage\" />';
xmlHelpSystemData += '    </CatapultSkin>';
xmlHelpSystemData += '</WebHelpSystem>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('HelpSystem', xmlHelpSystemData);
