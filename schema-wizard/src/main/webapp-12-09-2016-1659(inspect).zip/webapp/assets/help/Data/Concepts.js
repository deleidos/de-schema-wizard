var xmlConceptsData = "";
xmlConceptsData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlConceptsData += '<CatapultTargetConcepts />';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Concepts', xmlConceptsData);
